import tkinter as tk
from tkinter import ttk
from time import sleep
import sqlite3


app = tk.Tk()
app.title('Список сотрудников компани')
app.geometry('300x400')

frm = ttk.Frame(app, padding=10)

connection = sqlite3.connect('Main_db.db')
cursor = connection.cursor()

########################################

def add_user():
    name = name_p.get()
    tel = tel_p.get()
    mail = mail_p.get()
    zarp = zarp_p.get()

    if(name != '' and tel != '' and mail != '' and zarp != ''):
        query_insert = '''
        INSERT INTO Workers(name, number, mail, zarplata)
        VALUES (?, ?, ?, ?)
        '''
        user_data = (name, tel, mail, zarp)
        cursor.execute(query_insert, user_data)
        connection.commit()

        msg.config(text="Сотрудник добавлен!", fg="green")
    else:
        msg.config(text="Вы ввели не всю информацию!", fg="red")




name_l = ttk.Label(frm, text = "ФИО")
name_p = ttk.Entry(frm)

tel_l = ttk.Label(frm, text = "Номер телефона")
tel_p = ttk.Entry(frm)

mail_l = ttk.Label(frm, text = "Почта")
mail_p = ttk.Entry(frm)

zarp_l = ttk.Label(frm, text = "Зарплата")
zarp_p = ttk.Entry(frm)



name_l.grid(row=0, column=0, sticky="e", padx=5, pady=10)
name_p.grid(row=0, column=1, pady=5)

tel_l.grid(row=1, column=0, sticky="e", padx=5, pady=10)
tel_p.grid(row=1, column=1, pady=5)

mail_l.grid(row=2, column=0, sticky="e", padx=5, pady=10)
mail_p.grid(row=2, column=1, pady=5)

zarp_l.grid(row=3, column=0, sticky="e", padx=5, pady=10)
zarp_p.grid(row=3, column=1, pady=5)


frm.pack()



msg = tk.Label(app, text = '', fg="green")
msg.pack()

button1 = tk.Button(app, text = 'Добавить сотрудника', command=lambda: add_user())
button1.pack(side = 'bottom', pady= 10)


########################################
app.protocol('WM_DELETE_WINDOW', app.quit)
app.mainloop()