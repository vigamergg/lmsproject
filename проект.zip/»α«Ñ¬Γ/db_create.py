import sqlite3

connection = sqlite3.connect('Main_db.db')
cursor = connection.cursor()

query_create_table = '''
CREATE TABLE IF NOT EXISTS Workers(
    id INTEGER PRIMARY KEY,
    Name TEXT NOT NULL,
    number TEXT NOT NULL,
    mail TEXT NOT NULL,
    zarplata TEXT NOT NULL
)
'''

cursor.execute(query_create_table)
connection.commit()
